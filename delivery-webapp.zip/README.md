# Delivery Webapp - Demo (Server + Client)
This package contains a simple fullstack demo (Node.js/Express + Socket.io + MongoDB) server and a client built with HTML/CSS/JS.
## Quick start
1. Install Node.js and MongoDB locally (or use MongoDB Atlas).
2. Server: `cd server` then `npm install` then `npm run dev` (or `npm start`).
3. Client: open `client/index.html` in your browser or serve it with a static server.
4. The server listens on port 3000 by default. Adjust the `API` constant in `client/js/main.js` if needed.
## Notes
- This is a demo scaffold. For production, add authentication, validation, and secure file storage (S3 or similar).
- Keep sensitive keys out of source control (.env + secrets).

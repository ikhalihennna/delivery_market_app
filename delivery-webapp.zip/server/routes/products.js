const express = require('express');
const router = express.Router();
const multer = require('multer');
const Product = require('../models/Product');

const storage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, './uploads/'); },
  filename: function (req, file, cb) { cb(null, Date.now() + '-' + file.originalname); }
});
const upload = multer({ storage });

// Create product (merchant)
router.post('/', upload.array('images', 5), async (req, res) => {
  try {
    const { merchantId, name, description, price, stock } = req.body;
    const images = (req.files || []).map(f => '/uploads/' + f.filename);
    const p = new Product({ merchantId, name, description, price, stock, images });
    await p.save();
    res.json(p);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// List products (all or by merchant)
router.get('/', async (req, res) => {
  const { merchantId } = req.query;
  const q = merchantId ? { merchantId } : {};
  const products = await Product.find(q).sort({ createdAt: -1 });
  res.json(products);
});

router.put('/:id', upload.array('images', 5), async (req, res) => {
  try {
    const { id } = req.params;
    const body = req.body;
    if (req.files && req.files.length) {
      body.images = (req.files||[]).map(f => '/uploads/' + f.filename);
    }
    const updated = await Product.findByIdAndUpdate(id, body, { new: true });
    res.json(updated);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;

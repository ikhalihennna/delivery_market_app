const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
  merchantId: String,
  name: String,
  description: String,
  price: Number,
  images: [String],
  stock: Number,
}, { timestamps: true });
module.exports = mongoose.model('Product', productSchema);

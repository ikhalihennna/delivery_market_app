const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const socketio = require('socket.io');
const path = require('path');

const productsRoutes = require('./routes/products');

const app = express();
const server = http.createServer(app);
const io = socketio(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/products', productsRoutes);

io.on('connection', (socket) => {
  console.log('socket connected', socket.id);

  socket.on('join', (chatId) => { socket.join(chatId); });

  socket.on('chatMessage', (payload) => {
    io.to(payload.chatId).emit('newMessage', payload);
  });

  socket.on('driverLocation', (payload) => {
    io.to(payload.orderId).emit('driverLocationUpdate', payload);
  });

  socket.on('disconnect', () => {
    console.log('socket disconnected', socket.id);
  });
});

// Replace with your MongoDB URI if needed
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/deliverydb';

mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('MongoDB connected');
    server.listen(process.env.PORT || 3000, () => console.log('Server running on port 3000'));
  })
  .catch((err) => console.error(err));

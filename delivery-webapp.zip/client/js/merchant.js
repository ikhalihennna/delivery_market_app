document.getElementById('addProductForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const fd = new FormData();
  fd.append('merchantId','merchant-demo');
  fd.append('name', form.name.value);
  fd.append('price', form.price.value);
  Array.from(form.images.files).forEach(f => fd.append('images', f));
  try {
    const res = await fetch('http://localhost:3000/api/products', { method:'POST', body: fd });
    if (res.ok) { alert('تم الإضافة'); loadProducts(); loadMerchantProducts(); }
  } catch (err) { console.error(err); alert('خطأ'); }
});

async function loadMerchantProducts() {
  const res = await fetch('http://localhost:3000/api/products?merchantId=merchant-demo');
  const data = await res.json();
  const c = document.getElementById('merchantProducts'); c.innerHTML='';
  data.forEach(p => {
    const div = document.createElement('div');
    div.innerHTML = `<strong>${p.name}</strong> - ${p.price} <button onclick="deleteProduct('${p._id}')">حذف</button>`;
    c.appendChild(div);
  });
}
async function deleteProduct(id) {
  await fetch(`http://localhost:3000/api/products/${id}`, { method: 'DELETE' });
  loadMerchantProducts();
}
loadMerchantProducts();

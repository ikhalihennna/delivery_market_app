const API = 'http://localhost:3000/api';

function showRole(role) {
  document.querySelectorAll('.role-section').forEach(s=> s.style.display='none');
  document.getElementById(role).style.display = 'block';
  document.getElementById('chat').style.display = 'none';
}

async function loadProducts() {
  try {
    const res = await fetch(`${API}/products`);
    const data = await res.json();
    const container = document.getElementById('productsList');
    container.innerHTML = '';
    data.forEach(p => {
      const el = document.createElement('div');
      el.className = 'product';
      el.innerHTML = `<div style="flex:1"><strong>${p.name}</strong><div>${p.price} USD</div></div>`;
      container.appendChild(el);
    });
  } catch (err) {
    console.error('Failed to load products', err);
  }
}

window.onload = () => { loadProducts(); showRole('customer'); };

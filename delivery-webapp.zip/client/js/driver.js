const socket = io('http://localhost:3000');
let watchId = null;
function startDriverTracking() {
  if (!navigator.geolocation) return alert('الموقع غير مدعوم');
  watchId = navigator.geolocation.watchPosition(pos => {
    const payload = {
      driverId: 'driver-demo',
      lat: pos.coords.latitude,
      lng: pos.coords.longitude,
      orderId: 'order-demo'
    };
    socket.emit('driverLocation', payload);
    updateMapMarker(payload.lat, payload.lng);
  }, err => console.error(err), { enableHighAccuracy:true, maximumAge: 10000 });
}

const map = L.map('map').setView([21.4234, 39.8232], 12);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution:'' }).addTo(map);
let marker = null;
function updateMapMarker(lat, lng){
  if(!marker) marker = L.marker([lat,lng]).addTo(map);
  else marker.setLatLng([lat,lng]);
  map.setView([lat,lng], 14);
}

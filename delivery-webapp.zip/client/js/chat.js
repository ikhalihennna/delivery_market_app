const socketChat = io('http://localhost:3000');
let currentChatId = null;
function openChat(myRole, peerId){
  currentChatId = `chat_${myRole}_${peerId}`;
  document.getElementById('chat').style.display = 'block';
  document.getElementById('messages').innerHTML = '';
  socketChat.emit('join', currentChatId);
}

socketChat.on('newMessage', (msg) => {
  if (msg.chatId !== currentChatId) return;
  const m = document.createElement('div');
  m.textContent = `${msg.from}: ${msg.text}`;
  document.getElementById('messages').appendChild(m);
});

function sendMessage(){
  const text = document.getElementById('msgText').value;
  if (!text) return;
  const payload = {
    chatId: currentChatId,
    from: 'me-demo',
    to: 'peer-demo',
    text,
    type: 'text',
    timestamp: Date.now()
  };
  socketChat.emit('chatMessage', payload);
  document.getElementById('msgText').value = '';
}
function closeChat(){
  document.getElementById('chat').style.display = 'none';
}
